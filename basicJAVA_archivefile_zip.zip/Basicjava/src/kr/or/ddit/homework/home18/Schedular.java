package kr.or.ddit.homework.home18;

public abstract class Schedular {
	public abstract void getNextCall(); 
	public abstract void sendCallToAgent();
}
