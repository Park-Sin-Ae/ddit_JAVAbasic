package kr.or.ddit.homework;

public enum Oper {
	PLUS, MINUS, GDP, NANUGI, PER;
}
