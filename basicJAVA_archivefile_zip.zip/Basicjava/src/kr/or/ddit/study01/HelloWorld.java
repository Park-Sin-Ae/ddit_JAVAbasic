package kr.or.ddit.study01;

public class HelloWorld {
	public static void main(String[] args) {
		System.out.println("헬로우 월드");
		System.out.println("박신애");
	}
}
