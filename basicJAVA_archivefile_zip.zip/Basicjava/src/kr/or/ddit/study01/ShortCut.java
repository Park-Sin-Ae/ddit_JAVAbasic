package kr.or.ddit.study01;

public class ShortCut {
	public static void main(String[] args) {
		/*
		 *	단축키 
		 * 	ctrl + shift + L : 모든 단축키 안내
		 *  ctrl + space	 : 자동 완성
		 *  ctrl + shift + / : 범위 주석 단축키
		 *  ctrl + shift + C : 한줄 주석/취소
		 *  ctrl + N 		 : 신규 생성
		 *  ctrl + A		 : 전체 선택
		 *  ctrl + shift + F : 자동 정렬
		 *  ctrl + alt + 방향키: 한줄 복사
		 *  ctrl + D		 : 한줄 삭제
		 *  ctrl + Z		 : 실행 취소
		 *  ctrl + Y		 : 실행 취소의 취소
		 *  ctrl + S		 : 저장
		 *  ctrl + shift + S : 전체 저장
		 *  
		 *  
		 *  ctrl + F11		 : 실행
		 *  F11				 : 디버그 모드로 실행
		 *  (디버그 모드에서) F8	 : 다음 중단점
		 *  (디버그 모드에서) F6	 : 다음 라인
		 *  
		 *  alt + shift + R : 변수 전체 이름 변경
		 *  alt + shift + A : 여러줄 한번에 수정
		 */
		
		/*
		 * System.out.println("테스트1"); System.out.println("테스트1");
		 * System.out.println("테스트1"); System.out.println("테스트1");
		 * System.out.println("테스트1");
		 */

//		System.out.println("테스트1");
//		System.out.println("테스트1");
//		System.out.println("테스트1");
		
		int x123 = 10;
		x123=7;
		x123=7;
		System.out.println(x123);
		System.out.println(x123);
		System.out.println(x123);
	}
}
