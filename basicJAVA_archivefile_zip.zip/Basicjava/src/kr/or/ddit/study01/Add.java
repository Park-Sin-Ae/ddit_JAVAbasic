package kr.or.ddit.study01;

public class Add {
	public static void main(String[] args) {
		int x;		// 변수 x 선언
		x=1;		// x에 1을 저장
		int y=3;	// y 선언 후 3저장 
		
		// x+y 값 출력
		System.out.println(x+y);
	}
}
