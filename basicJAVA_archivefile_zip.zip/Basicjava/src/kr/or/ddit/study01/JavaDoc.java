package kr.or.ddit.study01;

/**
 * @since  23.12.21.
 * @author 박신애
 * 		     자바 주석	
 *
 */
public class JavaDoc {
	public static void main(String[] args) {
		// 라인 주석 // 부터 끝까지 주석으로 처리합니다.
		/*
		 * 범위 주석 /*와*\/ 사이에 있는 내용은 모두 주석으로 처리합니다.
		 * 
		 */
		/**
		 * 도큐먼트 주석
		 *	/**와 *\/ 사이에 있느 내용은 모두 주석으로 처리합니다.
		 *	주로 javadoc 명령어로 API 도큐먼트를 생성하는데 사용합니다.
		 *
		 */
/*		System.out.println("실행문1"); 
		System.out.println("실행문2");
		System.out.println("실행문3");
		*/
		System.out.println("실행문4");
		System.out.println("실행문5");
		System.out.println("실행문6");
	}
}
