package kr.or.ddit.study06.sec02;

public class Tv { // 저장공간을 만듬(붕어빵틀)
	String company;
	int year;
	double size;
}
