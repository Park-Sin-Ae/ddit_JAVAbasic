package kr.or.ddit.study06.sec03;

public class TriangleExample {
	public static void main(String[] args) {
		Triangle t1 = new Triangle(0, 0, 10, 0, 0, 10);
		System.out.println(t1);
	}
}
