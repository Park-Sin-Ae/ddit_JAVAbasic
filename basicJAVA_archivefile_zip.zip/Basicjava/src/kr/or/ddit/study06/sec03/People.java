package kr.or.ddit.study06.sec03;

public class People {
	String name;
	int age;
	
	public People(String name, int age) {
		this.name = name;
		this.age = age;
	}
}
