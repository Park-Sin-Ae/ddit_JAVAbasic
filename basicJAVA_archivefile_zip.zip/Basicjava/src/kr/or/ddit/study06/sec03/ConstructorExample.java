package kr.or.ddit.study06.sec03;

public class ConstructorExample {
	public static void main(String[] args) {
		Constructor c = new Constructor(10);
	}
}
