package kr.or.ddit.study06.sec01;

public class ClassExample {
	// 필드
	String filed1;
	int filed2;
	
	
	// static 필드
	static double filed3;
	
	// -------------------------------------
	// 메인 메소드
	public static void main(String[] args) {
		
	}
	
	// method1 메소드
	public void method1() {
		
	}
	
	// -------------------------------------
	// 기본 생성자
	public ClassExample() {
		
	}
}
