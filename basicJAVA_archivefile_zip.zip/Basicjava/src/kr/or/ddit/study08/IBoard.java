package kr.or.ddit.study08;

public interface IBoard {
	
	public void writeBoard(String title, String content);
}
