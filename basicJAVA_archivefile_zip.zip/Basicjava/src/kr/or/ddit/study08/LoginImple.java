package kr.or.ddit.study08;

public class LoginImple implements ILogin {

	@Override
	public boolean login(String id, String pass) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean sign(String id, String pass, String name, String tell) {
		// TODO Auto-generated method stub
		return false;
	}

}
