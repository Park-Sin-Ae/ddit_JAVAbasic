package kr.or.ddit.study07.sec01.prod;

public class Etc extends Prod {
	boolean ageChk;
	
}
