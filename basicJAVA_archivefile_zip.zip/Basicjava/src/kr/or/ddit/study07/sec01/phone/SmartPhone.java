package kr.or.ddit.study07.sec01.phone;

public class SmartPhone extends CameraPhone {
	public void touch() {
		System.out.println("터치기능탑재 스마트폰");
		
	}
	
	public void internet() {
		System.out.println("인터넷기능지원 스마트폰");
	}
}
