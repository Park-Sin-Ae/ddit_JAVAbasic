package kr.or.ddit.study07.sec01.prod;

public class Food extends Prod {
	String expire;
	String cal;
	
}
