package kr.or.ddit.study07.sec01.prod;

public class Prod {
	/*
	 *  편의점, 
	 *  상품이름, 가격, 타입
	 */
	
	String name;
	int price;
	String type;
	
}
