package kr.or.ddit.study07.sec01.phone;

public class FolderPhone extends Phone {
	
	public void fold() {
		System.out.println("접힌다.");
	}
}
