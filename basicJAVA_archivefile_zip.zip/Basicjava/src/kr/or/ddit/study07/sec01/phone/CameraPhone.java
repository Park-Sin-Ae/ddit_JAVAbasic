package kr.or.ddit.study07.sec01.phone;

public class CameraPhone extends Phone {
	public void camera() {
		System.out.println("찰칵");
	}
}
