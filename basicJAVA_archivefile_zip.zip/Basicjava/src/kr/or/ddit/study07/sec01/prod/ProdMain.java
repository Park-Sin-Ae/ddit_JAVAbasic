package kr.or.ddit.study07.sec01.prod;

public class ProdMain {
	public static void main(String[] args) {
		Food food = new Food();
		food.cal ="";
		food.expire = "";
		food.name = "";
	}

}
