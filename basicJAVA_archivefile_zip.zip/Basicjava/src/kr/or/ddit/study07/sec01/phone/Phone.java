package kr.or.ddit.study07.sec01.phone;

public class Phone {

	public void call() {
		System.out.println("전화를 겁니다.");
	}
}
