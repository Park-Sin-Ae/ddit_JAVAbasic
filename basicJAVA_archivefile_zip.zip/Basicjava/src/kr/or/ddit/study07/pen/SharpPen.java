package kr.or.ddit.study07.pen;

public class SharpPen {
	/*
	 *  amount 남은 양
	 *  width 펜의 굵기
	 */
	
	int amount;
	int width;
	

}
