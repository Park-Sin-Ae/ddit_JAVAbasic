package kr.or.ddit.study07.pen;

public class BallPen {
	/*
	 * color  색상
	 * amount 남은양
	 */

	public void color() {
		
	}
	
	public void amount() {
		
	}

}
