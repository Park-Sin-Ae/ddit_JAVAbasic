package kr.or.ddit.study07.pen;

public class Pen {

}
