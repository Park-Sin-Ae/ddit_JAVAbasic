package kr.or.ddit.study07.sec02;

public class Cat extends Animal {
	public void cry() {
		System.out.println("야옹");
	}
}
