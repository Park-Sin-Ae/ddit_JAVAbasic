package kr.or.ddit.study07.sec02;

public class Animal {
	public void cry() {
		System.out.println("동물 울음소리");
	}
}
