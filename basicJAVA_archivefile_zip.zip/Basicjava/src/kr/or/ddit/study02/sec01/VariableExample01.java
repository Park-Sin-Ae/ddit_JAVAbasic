package kr.or.ddit.study02.sec01;

public class VariableExample01 {
	static short sh = 1;
	
	public static void main(String[] args) {
		int Value = 100;
		String name = "홍길동";
		boolean flag = false;
		Shape s = new Shape();
	}

}

class Shape {
	String shape;
}
