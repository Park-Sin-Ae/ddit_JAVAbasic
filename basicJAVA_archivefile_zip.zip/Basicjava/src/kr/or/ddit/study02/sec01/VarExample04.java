package kr.or.ddit.study02.sec01;

public class VarExample04 {
	public static void main(String[] args) {
		/*
		 * 	1.변수 x 선언하고
		 * 	2.값을 10 저장해보기
		 * 	3. 저장된 값을 출력해보기
		 */
		
		int x;
		x = 10;
		
		
		int y = 999;
		
		int z = x+y;
		System.out.println(y);
		System.out.println(x);
		System.out.println(z);
	}

}
