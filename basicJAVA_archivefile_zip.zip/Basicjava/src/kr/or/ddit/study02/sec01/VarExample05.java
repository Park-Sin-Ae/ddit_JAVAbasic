package kr.or.ddit.study02.sec01;

public class VarExample05 {
	
	/*
	 * 	변수이름 규치
	 * 	1. 첫번째 글자는 문자이거나 $, _ 이어야하고 숫자로 시작 x
	 * 	2. 영어 대소문자를 구분
	 * 	3. 첫문자는 소문자 중간 단어는 대문자 (필수는 아님)
	 * 	4. 변수 길이는 제한 없음.
	 * 	5. 예약어는 사용 불가.
	 */
	
	
	/*
	 *  1
	 */
	int $a;
	int _a;
//	int 1a; 사용 불가
	
	/*
	 * 	2
	 */
	
	int a;
	int A;
	
	/*
	 *	3 
	 */
	
	int maxSpeed;
	int sellPrice;
	
	/*
	 * 	4
	 */
	
	int ccccccccccccccccccccccccccccccccc;
	
	/*
	 * 	5
	 */
	
//	int int; 예약어는 사용 불가.
}
