package kr.or.ddit.study02.sec01;

public class VarExample03 {
	public static void main(String[] args) {
//		int x;
//		int y;
//		int z;
//		x =10;
//		y =11;
//		z =12;
		
//		int x, y, z;
//		x = 10;
//		y = 11;
//		z = 12;
		
		int x = 10;
		int y = 11;
		int z = 12;
	
	}

}
