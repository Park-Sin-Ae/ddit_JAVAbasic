package kr.or.ddit.study02.sec03;

public class WrapperClass {
	public static void main(String[] args) {
		//	박싱, 안박싱
		
		//	박싱(기본타입 -> wrapper) 자동 박싱
		int n = 10;
		Integer num1 = n;
		
		//	언박싱(Wrapper -> 기본타입) 자동 언박싱
		Integer num2 = 11;
		int n2 = num2;
		

	}
}
