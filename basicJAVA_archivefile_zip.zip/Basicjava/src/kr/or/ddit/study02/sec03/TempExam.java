package kr.or.ddit.study02.sec03;

import java.util.Scanner;

public class TempExam {
	Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		TempExam obj = new TempExam();
	}
}
