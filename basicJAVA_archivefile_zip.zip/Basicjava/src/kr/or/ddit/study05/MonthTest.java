package kr.or.ddit.study05;

public class MonthTest {
	public static void main(String[] args) {
		
	}
}
