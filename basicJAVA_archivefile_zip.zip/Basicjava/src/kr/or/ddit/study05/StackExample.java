package kr.or.ddit.study05;

public class StackExample {
	public static void main(String[] args) {
		int a = 10;
		//1
		if(a==10) {
			int b = 8;
			int c = 7;
			//1
		}
		int d = 5;
		//3
	}
}
