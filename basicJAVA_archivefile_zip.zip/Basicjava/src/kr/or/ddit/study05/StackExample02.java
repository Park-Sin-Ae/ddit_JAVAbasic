package kr.or.ddit.study05;

public class StackExample02 {
	public static void main(String[] args) {
		int a = 5;
		//1
		if(a==5) {
			char b ='a';
			if(b=='a') {
				String c = "테스트";
				//3
			}
			if(true) {
				String d = "테스트";
				//4
			}
		}
		double e = 10.7;
		
		//5
	}
}
