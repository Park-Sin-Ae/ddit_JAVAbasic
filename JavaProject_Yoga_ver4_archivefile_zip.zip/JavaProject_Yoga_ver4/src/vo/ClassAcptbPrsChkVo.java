package vo;

import lombok.Data;

@Data
public class ClassAcptbPrsChkVo {
	
	private int class_no;
	private int acptb_prs;
	private int count_rgstr_no;

}
