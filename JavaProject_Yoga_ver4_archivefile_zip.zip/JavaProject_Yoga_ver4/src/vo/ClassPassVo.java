package vo;

import lombok.Data;

@Data
public class ClassPassVo {
	
	private int class_cnt;
	private int pass_price;
	private String pass_no;

}
