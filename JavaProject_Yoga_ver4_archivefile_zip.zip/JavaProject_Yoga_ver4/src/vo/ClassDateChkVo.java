package vo;

import lombok.Data;

@Data
public class ClassDateChkVo {

	private String mem_id;
	private int rgstr_no;
	private int class_no;
	private String class_name;
	private String class_date;
	private String cncl_yn;
}
