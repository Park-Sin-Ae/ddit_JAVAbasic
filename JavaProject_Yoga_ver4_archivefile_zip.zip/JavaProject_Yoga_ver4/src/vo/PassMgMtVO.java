package vo;

import lombok.Data;

@Data
public class PassMgMtVO {
	private int rgstr_cnt;
	private int rmn_cnt;
	private String mem_id;
	private String pass_no;
	private int pur_no;
}
