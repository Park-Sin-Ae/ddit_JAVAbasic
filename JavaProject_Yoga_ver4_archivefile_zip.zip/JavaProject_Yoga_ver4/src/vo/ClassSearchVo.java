package vo;

import lombok.Data;

@Data
public class ClassSearchVo {
	private int class_no;
	private String class_date;
	private String cls_name;
	private String class_name;
	private int acptb_prs;
	private String instr_name;
	private String center_name;
	

}
