package vo;

import lombok.Data;

@Data
public class ClassClsVo {
	private String cls_no;
	private String cls_name;
	private String useyns;
}