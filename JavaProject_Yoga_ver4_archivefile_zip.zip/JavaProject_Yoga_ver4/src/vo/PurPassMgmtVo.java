package vo;

import lombok.Data;

@Data
public class PurPassMgmtVo {
	
	private String mem_id;
	private int pur_no;
	private String pass_no;
	private int rmn_cnt;
	private int rgstr_cnt;
	private String pass_str;
	private String pass_end;

}
